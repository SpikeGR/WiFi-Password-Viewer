//////////\\\\\\\\\\
WiFi Password Viewer V2.2
Created by SpikeGR
//////////\\\\\\\\\\

Did you forget your WiFi password?

No worries, this program can show you the WiFi password
easily as long as you already connected to it at least one time
before, because the way this program works is by looking at the
saved WiFi which you already entered the password in the past.

WARNING:

DO NOT DELETE/RENAME OR EDIT ANY OF THE FILES. DOING SO MIGHT COMPLETELY BREAK THE PROGRAM!
YOU HAVE BEEN WARNED!

//////////\\\\\\\\\\
WiFi Password Viewer V2.2
Created by SpikeGR
//////////\\\\\\\\\\

-----
If you want to get in touch with me, below are my Social Media!

►YouTube:
youtube.com/spikegreece

►Instagram:
instagram.com/spikegr_official

►TikTok:
tiktok.com/@spikegr_yt

►Website:
www.spikegr.cf
-----